var weapons : Transform[];

function Start()
{
}

function Update()
{
}
