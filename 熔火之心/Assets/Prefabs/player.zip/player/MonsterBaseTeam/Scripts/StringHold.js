#pragma strict

var setString : String;

function Start () {

}

function Update () {

}